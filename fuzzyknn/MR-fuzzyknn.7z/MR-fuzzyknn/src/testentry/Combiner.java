package testentry;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import util.OpUtils;

public class Combiner extends Reducer<Text, Text, Text, Text> {
	
	//	��������K������
	int k;
	
	@Override
	//	��ʼ��K������
	protected void setup(Context context) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		k = context.getConfiguration().getInt("k", 2);
	}
	
	@Override
	/*
	 * function:�ڸ��ڵ㱾���ҵ�K������
	 */
	protected void reduce(Text key, Iterable<Text> value, Context context)
			throws IOException, InterruptedException {
		ArrayList<String> kNearest = OpUtils.kNearest(value.iterator(), k);
		for (String line : kNearest) {
			context.write(key, new Text(line));
		}
	}

}

package testentry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class TestEntryDriver {
	/*
	 * function:����MapReduce���������
	 * param0: ����2�����·������ѵ�����������Ⱦ���
	 * param1����������·��
	 * param2: ���Լ�·��
	 * param3: ������
	 */
	
	public static void Driver(String trainmemship, String outputpath, String testsetpath, int knearest) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		job.getConfiguration().set("testsetpath", testsetpath);
		job.getConfiguration().setInt("k", knearest);
		
		job.setJarByClass(TestEntryDriver.class);
		
		job.setMapperClass(TestMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setReducerClass(TestReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		job.setCombinerClass(Combiner.class);
		
		FileInputFormat.setInputPaths(job, new Path(trainmemship));
		FileOutputFormat.setOutputPath(job, new Path(outputpath));
		
		job.waitForCompletion(true);
	}
}

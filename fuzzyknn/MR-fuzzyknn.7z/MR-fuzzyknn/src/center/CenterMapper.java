package center;

import java.io.IOException;

import java.util.Arrays;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import util.OpUtils;

public class CenterMapper extends Mapper<LongWritable, Text, IntWritable, Text> {

	@Override
	/*
	 * function:�γɹ̶��ļ�ֵ�Դ���reduce
	 * param0: ƫ���� 
	 * param1��һ��ѵ������ 
	 * param2: ������
	 * output: ����꣬��Ӧ������ֵ��
	 */
	protected void map(LongWritable key, Text value, Context context)
			throws IOException, InterruptedException {
		String[] split = value.toString().split(",");
		String[] attribute = Arrays.copyOfRange(split, 0, split.length - 1);
		int label = Integer.parseInt(split[split.length - 1]);
		String att = OpUtils.arrayToString(attribute);
		context.write(new IntWritable(label), new Text(att));
	}
	
}

package center;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class CenterDriver {

	/*
	 * function:����MapReduce���������
	 * param0: ����ѵ������·��
	 * param1����������·��
	 * param2: �������Ե�ά��
	 */
	public static void Driver(String inputpath, String outputpath, int dim) throws IOException, Exception, InterruptedException {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		
		conf.setInt("dim", dim);
		
		job.setJarByClass(CenterDriver.class);
		job.setMapperClass(CenterMapper.class);
		job.setMapOutputKeyClass(IntWritable.class);
		job.setMapOutputValueClass(Text.class);
		job.setReducerClass(CenterReducer.class);
		job.setOutputKeyClass(IntWritable.class);
		job.setOutputValueClass(Text.class);
		
		FileInputFormat.setInputPaths(job, new Path(inputpath));
		FileOutputFormat.setOutputPath(job, new Path(outputpath));
		
		job.waitForCompletion(true);
	}
}

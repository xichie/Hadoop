package trainentry;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class EntryDriver {
	
	/*
	 * function:����MapReduce���������
	 * param0: ����ѵ������·��
	 * param1����������·��
	 * param2: ������ĵ����·��
	 */	
	public static void Driver (String inputpath, String trainEntryoutputpath, String sortCenteroutputpath) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf);
		job.getConfiguration().set("sortCenter", sortCenteroutputpath);
    

		job.setJarByClass(EntryDriver.class);
		
		job.setMapperClass(TrainMemshipMapper.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		
		job.setReducerClass(TrainMemshipReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(Text.class);
		
		FileInputFormat.setInputPaths(job, new Path(inputpath));
		FileOutputFormat.setOutputPath(job, new Path(trainEntryoutputpath));
		
		job.waitForCompletion(true);


	}
}

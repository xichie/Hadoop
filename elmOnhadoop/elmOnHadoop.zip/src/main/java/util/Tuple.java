package util;

public class Tuple {
	private double[] x = null;
	private double t;
	
	public Tuple() {
		super();
	}

	public Tuple(double[] x, double t) {
		super();
		this.x = x;
		this.t = t;
	}

	public double[] getX() {
		return x;
	}

	public void setX(double[] x) {
		this.x = x;
	}

	public double getT() {
		return t;
	}

	public void setT(double t) {
		this.t = t;
	}

	
	
	
}
